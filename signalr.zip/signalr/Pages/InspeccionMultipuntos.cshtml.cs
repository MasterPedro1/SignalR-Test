using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace signalr.Pages
{
    public class InspeccionMultipuntosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
